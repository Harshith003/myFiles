document.addEventListener('DOMContentLoaded', function() {
    var visibleCount = 2;
    var cards = document.querySelectorAll('.plan-card');
    var btn = document.getElementById('seeMoreBtn');

    function showCards() {
        cards.forEach(function(card, index) {
            if (index < visibleCount) {
                card.classList.add('visible');
            } else {
                card.classList.remove('visible');
            }
        });
        if (btn && visibleCount >= cards.length) {
            btn.style.display = 'none';
        }
    }

    if (btn) {
        btn.addEventListener('click', function() {
            visibleCount = cards.length;
            showCards();
        });
    }

    showCards();
});