(function () {
    var buttons = document.querySelectorAll('.spl-more-btn');
    buttons.forEach(function(btn) {
        var INITIAL = parseInt(btn.getAttribute('data-initial'), 10) || 4;
        var id      = btn.getAttribute('data-instance');
        var shown   = INITIAL;

        function refresh() {
            var grid = document.getElementById('splGrid_' + id);
            if (!grid) return;
            var cards = grid.querySelectorAll('.spl-card');
            cards.forEach(function (c, i) {
                c.classList.toggle('visible', i < shown);
            });
            btn.classList.toggle('spl-hidden', shown >= cards.length);
        }

        btn.addEventListener('click', function() {
            shown += INITIAL;
            refresh();
        });

        refresh();
    });
})();