package com.teleconnect.core.core.schedulers;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.scheduler.ScheduleOptions;
import org.apache.sling.commons.scheduler.Scheduler;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Node;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

@Component(service = Runnable.class, immediate = true)
@Designate(ocd = PlanCardScheduler.Config.class)
public class PlanCardScheduler implements Runnable {

    private static final Logger LOG = LoggerFactory.getLogger(PlanCardScheduler.class);

    @ObjectClassDefinition(name = "TeleConnect - Plan Card Scheduler")
    public @interface Config {

        @AttributeDefinition(name = "Scheduler Name")
        String schedulerName() default "TeleConnect Plan Card Scheduler";

        @AttributeDefinition(name = "Cron Expression")
        String cronExpression() default "0 * * * * ?";

        @AttributeDefinition(name = "Prepaid CSV DAM Path")
        String prepaidCsvPath() default "/content/dam/teleconnect/plans/prepaid-plans.csv";

        @AttributeDefinition(name = "Postpaid CSV DAM Path")
        String postpaidCsvPath() default "/content/dam/teleconnect/plans/postpaid-plans.csv";

        @AttributeDefinition(name = "Broadband CSV DAM Path")
        String broadbandCsvPath() default "/content/dam/teleconnect/plans/broadband-plans.csv";
    }

    @Reference
    private ResourceResolverFactory resourceResolverFactory;

    @Reference
    private Scheduler scheduler;

    private Config config;

    @Activate
    protected void activate(Config config) {
        this.config = config;
        addScheduler();
        LOG.info("PlanCardScheduler activated.");
    }

    @Deactivate
    protected void deactivate() {
        removeScheduler();
    }

    private void addScheduler() {
        ScheduleOptions options = scheduler.EXPR(config.cronExpression());
        options.name(config.schedulerName());
        scheduler.schedule(this, options);
    }

    private void removeScheduler() {
        scheduler.unschedule(config.schedulerName());
    }

    @Override
    public void run() {
        LOG.info("PlanCardScheduler started.");
        try {
            Map<String, Object> param = new HashMap<>();
            ResourceResolver resolver =
                resourceResolverFactory.getAdministrativeResourceResolver(param);

            importPlans(resolver, config.prepaidCsvPath(),
                "/content/teleconnect/us/en/prepaid");
            importPlans(resolver, config.postpaidCsvPath(),
                "/content/teleconnect/us/en/postpaid");
            importPlans(resolver, config.broadbandCsvPath(),
                "/content/teleconnect/us/en/broadband");

            resolver.close();
            LOG.info("PlanCardScheduler finished.");
        } catch (Exception e) {
            LOG.error("PlanCardScheduler error: {}", e.getMessage());
        }
    }

    private void importPlans(ResourceResolver resolver,
                             String csvPath,
                             String parentPagePath) {
        try {
            String fullPath = csvPath +
                "/jcr:content/renditions/original/jcr:content";
            org.apache.sling.api.resource.Resource csvResource =
                resolver.getResource(fullPath);

            if (csvResource == null) {
                LOG.warn("CSV not found: {}", fullPath);
                return;
            }

            InputStream inputStream =
                csvResource.adaptTo(InputStream.class);
            if (inputStream == null) {
                LOG.warn("InputStream null for: {}", fullPath);
                return;
            }

            PageManager pageManager = resolver.adaptTo(PageManager.class);
            BufferedReader reader =
                new BufferedReader(new InputStreamReader(inputStream));

            String line;
            boolean firstLine = true;
            while ((line = reader.readLine()) != null) {
                if (firstLine) { firstLine = false; continue; }
                String[] fields = line.split(",");
                if (fields.length < 5) continue;

                String planName       = fields[0].trim();
                String cost           = fields[1].trim();
                String validity       = fields[2].trim();
                String benefits       = fields[3].trim();
                String offers         = fields[4].trim();

                String pageName = planName.toLowerCase()
                    .replaceAll("\\s+", "-");

                Page existing = pageManager.getPage(
                    parentPagePath + "/" + pageName);

                if (existing == null) {
                    Page newPage = pageManager.create(
                        parentPagePath, pageName,
                        "/conf/teleconnect/settings/wcm/templates/teleconnect-temp",
                        planName);

                    Node content = newPage.getContentResource()
                        .adaptTo(Node.class);
                    content.setProperty("planName", planName);
                    content.setProperty("cost",     cost);
                    content.setProperty("validity", validity);
                    content.setProperty("benefits", benefits);
                    content.setProperty("offers",   offers);
                    resolver.commit();
                    LOG.info("Created plan page: {}", planName);
                }
            }
        } catch (Exception e) {
            LOG.error("importPlans error: {}", e.getMessage());
        }
    }
}