package com.teleconnect.core.core.models;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Model(
    adaptables = SlingHttpServletRequest.class,
    defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class ProductHighlightModel {

    @ValueMapValue
    private String productTitle;

    @ValueMapValue
    private String description;

    @ValueMapValue
    private String bannerImage;

    public String getProductTitle() { return productTitle; }
    public String getDescription() { return description; }
    public String getBannerImage() { return bannerImage; }
}