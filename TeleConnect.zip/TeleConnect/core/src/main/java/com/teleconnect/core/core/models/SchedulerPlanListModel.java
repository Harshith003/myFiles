package com.teleconnect.core.core.models;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

@Model(
    adaptables = SlingHttpServletRequest.class,
    defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class SchedulerPlanListModel {

    private static final Logger LOG = LoggerFactory.getLogger(SchedulerPlanListModel.class);

    @ValueMapValue
    private String sectionTitle;

    @ValueMapValue
    private String plansRootPath;

    @ValueMapValue
    private Long initialCount;

    @SlingObject
    private ResourceResolver resourceResolver;

    @SlingObject
    private SlingHttpServletRequest request;

    private List<PlanItem> plans = new ArrayList<>();
    private String instanceId;

    @PostConstruct
    protected void init() {

        instanceId = Integer.toHexString(
            request.getResource().getPath().hashCode());

        if (plansRootPath == null || plansRootPath.trim().isEmpty()) {
            LOG.warn("SchedulerPlanListModel - plansRootPath not configured.");
            return;
        }

        Resource pageResource = resourceResolver.getResource(plansRootPath);
        if (pageResource == null) {
            LOG.warn("SchedulerPlanListModel - path not found: {}", plansRootPath);
            return;
        }

        for (Resource child : pageResource.getChildren()) {
            if (!child.getValueMap().get("jcr:primaryType", "")
                    .equals("cq:Page")) continue;

            Resource content = child.getChild("jcr:content");
            if (content == null) continue;

            String planName = content.getValueMap().get("planName", "");
            if (planName.isEmpty()) continue;

            PlanItem item = new PlanItem();
            item.setPlanName(planName);
            item.setCost(           content.getValueMap().get("cost",           ""));
            item.setValidity(       content.getValueMap().get("validity",       ""));
            item.setBenefits(       content.getValueMap().get("benefits",       ""));
            item.setAddedAdvantage( content.getValueMap().get("addedAdvantage", ""));
            item.setOffers(         content.getValueMap().get("offers",         ""));
            item.setProductType(    content.getValueMap().get("productType",    ""));
            plans.add(item);
            LOG.info("SchedulerPlanListModel - loaded plan: {}", planName);
        }

        LOG.info("SchedulerPlanListModel - total {} plans from {}",
            plans.size(), plansRootPath);
    }

    public List<PlanItem> getPlans()   { return plans; }
    public boolean getHasPlans()       { return !plans.isEmpty(); }
    public String getInstanceId()      { return instanceId; }

    public String getSectionTitle() {
        return (sectionTitle != null && !sectionTitle.trim().isEmpty())
            ? sectionTitle : "Available Plans";
    }

    public int getInitialCount() {
        return (initialCount != null && initialCount > 0)
            ? initialCount.intValue() : 4;
    }

    public static class PlanItem {
        private String planName;
        private String cost;
        private String validity;
        private String benefits;
        private String addedAdvantage;
        private String offers;
        private String productType;

        public String getPlanName()               { return planName; }
        public void   setPlanName(String v)       { planName = v; }

        public String getCost()                   { return cost; }
        public void   setCost(String v)           { cost = v; }

        public String getValidity()               { return validity; }
        public void   setValidity(String v)       { validity = v; }

        public String getBenefits()               { return benefits; }
        public void   setBenefits(String v)       { benefits = v; }

        public String getAddedAdvantage()         { return addedAdvantage; }
        public void   setAddedAdvantage(String v) { addedAdvantage = v; }

        public String getOffers()                 { return offers; }
        public void   setOffers(String v)         { offers = v; }

        public String getProductType()            { return productType; }
        public void   setProductType(String v)    { productType = v; }
    }
}