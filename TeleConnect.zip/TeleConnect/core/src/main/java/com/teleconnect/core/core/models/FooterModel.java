package com.teleconnect.core.core.models;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import java.util.List;

@Model(
    adaptables = SlingHttpServletRequest.class,
    defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class FooterModel {

    @ValueMapValue
    private String copyrightText;

    @ChildResource
    private List<FooterLink> footerLinks;

    public String getCopyrightText() { return copyrightText; }
    public List<FooterLink> getFooterLinks() { return footerLinks; }

    @Model(
        adaptables = Resource.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
    )
    public static class FooterLink {

        @ValueMapValue
        private String linkText;

        @ValueMapValue
        private String linkPath;

        public String getLinkText() { return linkText; }
        public String getLinkPath() { return linkPath; }
    }
}