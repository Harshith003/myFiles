package com.teleconnect.core.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Model(
    adaptables = Resource.class,
    defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class HeroBannerModel {

    @ValueMapValue
    private String pretitle;

    @ValueMapValue
    private String title;

    @ValueMapValue
    private String description;

    @ValueMapValue
    private String primaryLinkText;

    @ValueMapValue
    private String primaryLinkUrl;

    @ValueMapValue
    private String secondaryLinkText;

    @ValueMapValue
    private String secondaryLinkUrl;

    @ValueMapValue
    private String stat1Value;

    @ValueMapValue
    private String stat1Label;

    @ValueMapValue
    private String stat2Value;

    @ValueMapValue
    private String stat2Label;

    @ValueMapValue
    private String stat3Value;

    @ValueMapValue
    private String stat3Label;

    public String getPretitle() { return pretitle; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public String getPrimaryLinkText() { return primaryLinkText; }
    public String getPrimaryLinkUrl() { return primaryLinkUrl; }
    public String getSecondaryLinkText() { return secondaryLinkText; }
    public String getSecondaryLinkUrl() { return secondaryLinkUrl; }
    public String getStat1Value() { return stat1Value; }
    public String getStat1Label() { return stat1Label; }
    public String getStat2Value() { return stat2Value; }
    public String getStat2Label() { return stat2Label; }
    public String getStat3Value() { return stat3Value; }
    public String getStat3Label() { return stat3Label; }
}