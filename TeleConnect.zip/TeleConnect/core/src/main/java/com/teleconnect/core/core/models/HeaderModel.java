package com.teleconnect.core.core.models;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import java.util.List;

@Model(
    adaptables = SlingHttpServletRequest.class,
    defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class HeaderModel {

    @ValueMapValue
    private String logoPath;

    @ChildResource
    private List<NavLink> navLinks;

    public String getLogoPath() {
        return logoPath;
    }

    public List<NavLink> getNavLinks() {
        return navLinks;
    }

    @Model(
        adaptables = Resource.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
    )
    public static class NavLink {

        @ValueMapValue
        private String linkText;

        @ValueMapValue
        private String linkIcon;

        @ValueMapValue
        private String linkPath;

        public String getLinkText() { return linkText; }
        public String getLinkIcon() { return linkIcon; }
        public String getLinkPath() { return linkPath; }
    }
}