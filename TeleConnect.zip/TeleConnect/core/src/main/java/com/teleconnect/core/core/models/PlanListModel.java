package com.teleconnect.core.core.models;

import com.adobe.cq.dam.cfm.ContentFragment;
import com.adobe.cq.dam.cfm.ContentElement;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Model(
    adaptables = SlingHttpServletRequest.class,
    defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class PlanListModel {

    private static final Logger LOG = LoggerFactory.getLogger(PlanListModel.class);

    @SlingObject
    private ResourceResolver resourceResolver;

    @ValueMapValue
    private String sectionTitle;

    @ValueMapValue
    private String productType;

    private List<PlanItem> plans = new ArrayList<>();

    @PostConstruct
    protected void init() {

        // Map productType to CF folder path
        String cfRootPath = getCfRootPath(productType);

        if (cfRootPath == null) {
            LOG.warn("PlanListModel - unknown productType: {}", productType);
            return;
        }

        Resource cfFolder = resourceResolver.getResource(cfRootPath);
        if (cfFolder == null) {
            LOG.warn("PlanListModel - CF folder not found: {}", cfRootPath);
            return;
        }

        Iterator<Resource> children = cfFolder.listChildren();
        while (children.hasNext()) {
            Resource child = children.next();
            ContentFragment cf = child.adaptTo(ContentFragment.class);
            if (cf == null) continue;

            PlanItem item = new PlanItem();
            item.setPlanName(   getElementValue(cf, "planName"));
            item.setCost(       getElementValue(cf, "cost"));
            item.setValidity(   getElementValue(cf, "validity"));
            item.setBenefits(   getElementValue(cf, "benefits"));
            item.setAddedAdvantage(getElementValue(cf, "addedAdvantage"));
            item.setOffers(     getElementValue(cf, "offers"));
            item.setProductType(productType != null ? productType : "");
            plans.add(item);

            LOG.info("PlanListModel - loaded CF: {}", cf.getTitle());
        }

        LOG.info("PlanListModel - total plans loaded: {}", plans.size());
    }

    private String getCfRootPath(String type) {
        if (type == null) return null;
        switch (type.toLowerCase()) {
            case "prepaid":
                return "/content/dam/teleconnect/telconnectplans/prepaidplans";
            case "postpaid":
                return "/content/dam/teleconnect/telconnectplans/postpaidplans";
            case "broadband":
                return "/content/dam/teleconnect/telconnectplans/broadbandplans";
            default:
                return null;
        }
    }

    private String getElementValue(ContentFragment cf, String elementName) {
        try {
            ContentElement element = cf.getElement(elementName);
            if (element != null && element.getValue() != null
                    && element.getValue().getValue() != null) {
                return element.getValue().getValue().toString();
            }
        } catch (Exception e) {
            LOG.debug("PlanListModel - element not found: {}", elementName);
        }
        return "";
    }

    public List<PlanItem> getPlans()  { return plans; }
    public boolean getHasPlans()      { return !plans.isEmpty(); }
    public String getSectionTitle() {
        return (sectionTitle != null && !sectionTitle.isEmpty())
            ? sectionTitle : "Available Plans";
    }

    public static class PlanItem {
        private String planName;
        private String cost;
        private String validity;
        private String benefits;
        private String addedAdvantage;
        private String offers;
        private String productType;

        public String getPlanName()               { return planName; }
        public void   setPlanName(String v)       { planName = v; }
        public String getCost()                   { return cost; }
        public void   setCost(String v)           { cost = v; }
        public String getValidity()               { return validity; }
        public void   setValidity(String v)       { validity = v; }
        public String getBenefits()               { return benefits; }
        public void   setBenefits(String v)       { benefits = v; }
        public String getAddedAdvantage()         { return addedAdvantage; }
        public void   setAddedAdvantage(String v) { addedAdvantage = v; }
        public String getOffers()                 { return offers; }
        public void   setOffers(String v)         { offers = v; }
        public String getProductType()            { return productType; }
        public void   setProductType(String v)    { productType = v; }
    }
}